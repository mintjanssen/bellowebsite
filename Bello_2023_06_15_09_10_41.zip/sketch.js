let bellos = [];

class Dog {
  constructor(_name, _x, _y) {
    this.name = _name;
    this.x = _x;
    this.y = _y;
  }
  
  show(){
    ellipse(this.x, this.y, 20);
  }
}


function setup() {
  createCanvas(500, 500);
  for(let i = 0; i < 100; i++) {
    bellos.push(new Dog('Bello', random(0,500), random(0,500)));
  }
  
  
}


function draw(){
  
  for(let i = 0; i < 100; i++){
    bellos[i].show();
  }
}

function touchMoved() {
 
}

function touchStarted() {
  fullscreen(true);

}